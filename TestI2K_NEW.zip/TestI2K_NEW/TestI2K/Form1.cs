﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestI2K.WSFundus;
using log4net;
using System.Runtime.InteropServices;

namespace TestI2K
{
    public partial class Form1 : Form
    {
        public string filepath = null;
        public bool Threadflag = false;
        delegate void AsynUpdateUI(string step);
        private object oj = new object();

        private delegate void FlushClient();//代理
        public List<TaskTest> taskList = new List<TaskTest>();
        int maxThread = 10;  //10个并发线程
        int currTNum = 0;

        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodInfo.GetCurrentMethod().DeclaringType);
        public Form1()
        {
            InitializeComponent();
            timer1.Interval = 10000;
            bool re = EditImage.init();
            if (!re)
            {
                button1.Enabled = false;
                button2.Enabled = false;
            }
        }

        private int i = 0;

        /// <summary>
        /// 拼接
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            AddTask();
        }

        private void AddTask() {
            if (taskList.Count <= 0) {
                isworking = true;
                
                var threadName = "Thread" + currTNum.ToString();
                InitTaskList(threadName);
                Thread thread = new Thread(new ThreadStart(Montage));//创建线程  ParameterizedThreadStart
                thread.Name = threadName;
                thread.IsBackground = true;
                thread.Start();
                logger.Info($"{threadName} start montage：" + DateTime.Now.ToString());
                textBox3.Text = $"{DateTime.Now.ToString()} ：{threadName} 开始拼接：" + "\r\n" + textBox3.Text;

                currTNum++;
            }
        }

        bool isworking = true;
        public void Montage()
        {
            while (isworking)
            {
                Parallel.ForEach(taskList, new Action<TaskTest>(task =>
                {
                    var id = task.TaskID;
                    string path = "";
                    var msg = GetImage(ref path, task.TaskID.ToString());
                    if (!string.IsNullOrEmpty(msg))
                    {
                        //this.pictureBox1.Image = null;
                        if (this.pictureBox1.InvokeRequired)//不同线程访问了
                        {
                            //this.pictureBox1.Invoke(new Action<PictureBox, Image>(SetImage), pictureBox1, null);//跨线程了
                            this.textBox3.Invoke(new Action<TextBox, string>(SetTxtValue), textBox3, $"{DateTime.Now.ToString()} ：{id}结果：" + msg);//跨线程了
                        }
                        else//同线程直接赋值
                        {
                            //this.pictureBox1.Image = null;
                            textBox3.Text = $"{DateTime.Now.ToString()} ：{id}结果：" + msg + "\r\n" + textBox3.Text;
                        }

                        //MessageBox.Show(msg);
                        return;
                    }
                    //MessageBox.Show(path);
                    if (!string.IsNullOrWhiteSpace(path))
                    {
                        if (this.pictureBox1.InvokeRequired)//不同线程访问了
                        {
                            //this.pictureBox1.Invoke(new Action<PictureBox, string>(SetTxtValue), pictureBox1, path);//跨线程了
                            this.textBox3.Invoke(new Action<TextBox, string>(SetTxtValue), textBox3, $"{DateTime.Now.ToString()} ：{id}路径：" + path);//跨线程了
                        }
                        else {
                            //同线程直接赋值
                            //pictureBox1.Load(path);
                            this.textBox3.Text = $"{DateTime.Now.ToString()} ：{id}路径：" + path + "\r\n" + textBox3.Text;
                        }
                    }

                }));
                //Thread.Sleep(10000);
                isworking = false;

                taskList.Clear();
            }
            //string path = "";
            //string threadname = Thread.CurrentThread.Name;
            //var msg = GetImage(ref path, threadname);
            //if (!string.IsNullOrEmpty(msg))
            //{
            //    //this.pictureBox1.Image = null;
            //    if (this.pictureBox1.InvokeRequired)//不同线程访问了
            //        this.pictureBox1.Invoke(new Action<PictureBox, Image>(SetImage), pictureBox1, null);//跨线程了
            //    else//同线程直接赋值
            //        this.pictureBox1.Image = null;
            //    logger.Info(msg);
            //    //MessageBox.Show(msg);
            //    return;
            //}
            ////MessageBox.Show(path);
            //if (!string.IsNullOrWhiteSpace(path))
            //{
            //    if (this.pictureBox1.InvokeRequired)//不同线程访问了
            //    {
            //        this.pictureBox1.Invoke(new Action<PictureBox, string>(SetTxtValue), pictureBox1, path);//跨线程了
            //        logger.Info("拼接成功：" + DateTime.Now.ToString());
            //    }
            //    else//同线程直接赋值
            //    {
            //        logger.Info("拼接成功：" + DateTime.Now.ToString());
            //        this.pictureBox1.Load(path);
            //    }
            //}
            //Thread.CurrentThread.Abort();
        }

        public void InitTaskList(string threadName)
        {
            for (int i = 0; i < 1; i++)
            {
                taskList.Add(new TaskTest(threadName + i.ToString()));
            }
        }

        private void SetTxtValue(PictureBox txt, string value)
        {
            txt.Load(value);
        }

        private void SetTxtValue(TextBox txt, string value)
        {
            txt.Text = value + "\r\n" + txt.Text;
        }

        public string GetImage(ref string path, string name)
        {
            try
            {
                //lock(oj)
                {
                    string montage_file_name = EditImage.TestMontageMethod(this.textBox1.Text, name);
                    //string montage_file_name = EditImage.Montage(textBox1.Text);
                    string filename = string.Empty;
                    if (!string.IsNullOrEmpty(montage_file_name))
                    {
                        string[] patharray = montage_file_name.Split('\\');
                        filename = patharray[patharray.Length - 1];
                    }
                    if (!string.IsNullOrWhiteSpace(filename))
                    {
                        //path = textBox1.Text + "\\"+filename;
                        path = montage_file_name;
                    }
                    return "";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private int ImageIndex = 0;
        private List<string> Align_url_Array = new List<string>();

        /// <summary>
        /// 校准
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            Align_url_Array.Clear();
            var msg = GetImageAlign(ref Align_url_Array);

            //FlushMemory();

            if (!string.IsNullOrEmpty(msg))
            {
                pictureBox2.Image = null;
                MessageBox.Show(msg);
                return;
            }

            ImageIndex = 0;
            pictureBox2.Load(Align_url_Array[ImageIndex]);

            button3.Visible = true;
            button4.Visible = true;

            

            return;

            Thread thread = new Thread(new ThreadStart(Align));//创建线程  ParameterizedThreadStart
            thread.IsBackground = true;
            thread.Start();
            logger.Info("开始校准：" + DateTime.Now.ToString());
        }

        public void Align()
        {
            Align_url_Array.Clear();
            var msg = GetImageAlign(ref Align_url_Array);
            if (!string.IsNullOrEmpty(msg))
            {
                //pictureBox2.Image = null;
                if (this.pictureBox2.InvokeRequired)//不同线程访问了
                    this.pictureBox2.Invoke(new Action<PictureBox, Image>(SetImage), pictureBox2, null);//跨线程了
                else//同线程直接赋值
                    this.pictureBox2.Image = null;
                logger.Info(msg);
                //MessageBox.Show(msg);
                return;
            }

            ImageIndex = 0;
            if (this.pictureBox2.InvokeRequired)//不同线程访问了
            {
                this.pictureBox2.Invoke(new Action<PictureBox, string>(SetTxtValue), pictureBox2, Align_url_Array[ImageIndex]);//跨线程了
                this.button3.Invoke(new Action<Button, bool>(SetBool), button3, true);
                this.button4.Invoke(new Action<Button, bool>(SetBool), button4, true);
                logger.Info("校准成功：" + DateTime.Now.ToString());
                //this.button3.Visible = true;
                //this.button4.Visible = true;
            }
            else//同线程直接赋值
                pictureBox2.Load(Align_url_Array[ImageIndex]);
        }

        public void SetImage(PictureBox picture, Image value)
        {
            picture.Image = value;
        }
        public void SetBool(Button btn, bool value)
        {
            btn.Visible = value;
        }


        #region 内存回收
        [DllImport("kernel32.dll")]
        public static extern bool SetProcessWorkingSetSize(IntPtr proc, int min, int max);

        public void FlushMemory()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            if (Environment.OSVersion.Platform == PlatformID.Win32NT)
            {
                SetProcessWorkingSetSize(System.Diagnostics.Process.GetCurrentProcess().Handle, -1, -1);
            }
        }
        #endregion


        /// <summary>
        /// 同步对齐图像接口
        /// </summary>
        /// <param name="urls">url地址数组 (后 加入文件base64编码也可以直接上传)</param>
        /// <param name="username">用户名</param>
        /// <param name="password">密码</param>
        /// <param name="userId">用户id</param>
        /// <returns>FundusResult序列号对象，生成完成的对齐的图像url List </returns>
        public string GetImageAlign(ref List<string> Align_url_Array)
        {
            try
            {
                var yyymmddd = DateTime.Now.ToString("yyyyMMddHHmmss");
                //string[] Align_file_Array = EditImage.TestAlignMethods(textBox2.Text);
                string[] Align_file_Array = EditImage.TestAlignMethods1(textBox2.Text, yyymmddd);
                string filename = string.Empty;
                if (Align_file_Array != null && Align_file_Array.Count() > 0)
                {
                    foreach (var Align_file_name in Align_file_Array)
                    {
                        string[] patharray = Align_file_name.Split('\\');
                        filename = patharray[patharray.Length - 1];
                        Align_url_Array.Add(textBox2.Text + $@"\{yyymmddd.Substring(0,8)}\{yyymmddd}\aligned-images\" + filename);
                    }
                    MessageBox.Show("成功了");
                    return "";
                }
                else
                {
                    return "Align_file_Array is null or it's count is lower than 1";
                }
            }
            catch (Exception ex)
            {
                LogHelper.LogException.WriteError(ex);
                return "error";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (ImageIndex == 0)
            {
                MessageBox.Show("没有上一张");
                return;
            }
            ImageIndex--;
            pictureBox2.Load(Align_url_Array[ImageIndex]);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (ImageIndex == (Align_url_Array.Count - 1))
            {
                MessageBox.Show("没有下一张");
                return;
            }
            ImageIndex++;
            pictureBox2.Load(Align_url_Array[ImageIndex]);
        }

        int time = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            AddTask();
            //button2_Click(null, null);
        }
    }
}
