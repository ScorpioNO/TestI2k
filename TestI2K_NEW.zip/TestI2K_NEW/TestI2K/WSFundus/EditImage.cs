﻿using DualAlign;
using log4net;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TestI2K.WSFundus
{
    public class EditImage
    {
        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodInfo.GetCurrentMethod().DeclaringType);
        private static string license_path = Properties.Settings.Default.license_path;
        private static string outLogDir = Properties.Settings.Default.outLogDir;

        public static bool init()
        {
            var result = true;
            try
            {
                int trace_level = 0;
                String file_for_cout = @"C:\Users\HuiMu06\Downloads\i2kRetina-3.6.3Build419-windows-x32-devel\images\retina_montage" + @"\out.txt";//C:\\Users\\HuiMu06\\Downloads\\i2kRetina-3.6.3-x32-devel\\images\\retina_montage

                logger.Info("log path:" + file_for_cout);

                i2kRetinaErrorCode error_code = i2kRetina.da_i2k_initialize(license_path, trace_level, file_for_cout, out string error_msg);

                if (error_code != i2kRetinaErrorCode.success)
                {
                    result = false;
                    logger.Error("Failed to initialize i2k Retina");
                    logger.Error(error_msg);
                }
            }
            catch(Exception ex) {
                result = false;
                logger.Error("Failed to initialize i2k Retina");
                logger.Error(ex);
            }
            return result;
        }

        public static string MontageMethod(string filepath,string name)
        {
            string result = string.Empty;
            try
            {
                string error_msg;

                i2kRetinaErrorCode error_code = new i2kRetinaErrorCode();

                i2kRetina.da_i2k_input_file_info in_file_info = new i2kRetina.da_i2k_input_file_info();

                // Base path null here, specific image paths defined in the GetImageFilePaths method.
                in_file_info.image_path = null;
                List<String> imageFilePaths = GetImageFilePaths(
                      filepath,
                      new Regex(@"\w+\.(jpg|gif|bmp|png)$")
                      );

                // This is how many images the software will process.
                in_file_info.num_images = imageFilePaths.Count;
                in_file_info.image_files = GetImageFilePathsIntPtr(imageFilePaths);

                int images_type = i2kRetina.DA_I2K_IMAGES_RETINAL;
                int layout_type = i2kRetina.DA_I2K_LAYOUT_AUTO;
                int reg_id = 0;

                error_code = i2kRetina.da_i2k_start_from_new_images(in_file_info, images_type, layout_type, out reg_id, out error_msg);

                if (error_code != i2kRetinaErrorCode.success)
                {
                    logger.Error("Failed to start a new registration session");
                    logger.Error(error_msg);
                    return result;
                }

                i2kRetina.da_i2k_register_options_info reg_options = new i2kRetina.da_i2k_register_options_info();
                i2kRetina.da_i2k_default_register_options_info(ref reg_options);
                reg_options.use_distortion_correction = true;  // is it needed?

                error_code = i2kRetina.da_i2k_run_registration(reg_id, reg_options);

                if (!CheckError(reg_id, error_code))
                {
                    logger.Error("error_code = i2kRetina.da_i2k_run_registration(reg_id, reg_options);");
                    logger.Error(error_code);
                    return result;
                }
                
                int num_components;
                error_code = i2kRetina.da_i2k_how_many_components(reg_id, out num_components);

                int comp_index = 0;
                string[] image_names;
                error_code = i2kRetina.da_i2k_what_images_are_in_component(reg_id, comp_index, out image_names);

                //  Assign the options on the formation of the montage image
                i2kRetina.da_i2k_build_montage_options build_montage_options = new i2kRetina.da_i2k_build_montage_options();

                //build_montage_options.blend_option = i2kRetina.DA_I2K_BLEND_FULL;
                //build_montage_options.attempt_to_crop = true;
                //build_montage_options.area_pct_for_crop = i2kRetina.DA_I2K_CROP_AREA_PCT_DEFAULT;

                //  Assign the option on the output image
                i2kRetina.da_i2k_output_file_info out_file_info = new i2kRetina.da_i2k_output_file_info();
                out_file_info.path = filepath+ "\\montage-images\\";
                out_file_info.prefix = @"montage_"+ name +@"_"+ DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
                out_file_info.extension = @"jpg";

                i2kRetina.da_i2k_output_options out_options = new i2kRetina.da_i2k_output_options();

                //  Build the actual montage
                // Need strings first, intptrs second.
                string montage_file_name;

                error_code = i2kRetina.da_i2k_build_montage(reg_id, out_file_info, out_options, build_montage_options, out montage_file_name);

                if (!CheckError(reg_id, error_code))
                {
                    logger.Error("error_code = i2kRetina.da_i2k_build_montage(reg_id, out_file_info, out_options, build_montage_options, out montage_file_name);");
                    logger.Error(error_code);
                    return result;
                }

                error_code = i2kRetina.da_i2k_clear_registration(reg_id);
                if (!CheckError(reg_id, error_code))
                {
                    logger.Error("error_code =da_i2k_clear_registration(reg_id);");
                    logger.Error(error_code);
                    return result;
                }

                result = montage_file_name;
                return result;
            }
            catch (Exception ex) {
                LogHelper.LogException.WriteError(ex);
            }
            return result;
        }

        public static bool CheckError(int reg_id, i2kRetinaErrorCode error_code)
        {
            string error_msg;
            if (error_code != i2kRetinaErrorCode.success && error_code != i2kRetinaErrorCode.not_all_images_aligned)
            {
                error_msg = i2kRetina.da_i2k_get_error_message(reg_id);
                if (error_msg != null)
                {
                    //Console.WriteLine("i2k Retina return with error code " + error_code + ", error_message: " + error_msg);
                    return false;
                }
            }
            return true;
        }

        // Gets the image file paths.
        public static List<String> GetImageFilePaths(String folderName, Regex regex)
        {
            System.IO.DirectoryInfo Folder;
            System.IO.FileInfo[] Images;
            Folder = new System.IO.DirectoryInfo(folderName);
            Images = Folder.GetFiles();
            List<String> imagesList = new List<String>();
            try
            {
                for (int i = 0; i < Images.Length; i++)
                {
                    String name = Images[i].Name.ToLower();
                    Match match = regex.Match(name);
                    if (!match.Success) continue;
                    imagesList.Add(String.Format(@"{0}\{1}", folderName, name));
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }

            return imagesList;
        }

        public static IntPtr GetImageFilePathsIntPtr(List<String> imageFilePaths)
        {

            IntPtr[] image_files_array = new IntPtr[imageFilePaths.Count];

            for (int ii = 0; ii < imageFilePaths.Count; ii++)
            {
                image_files_array[ii] = Marshal.StringToCoTaskMemUni(imageFilePaths[ii]);
            }

            // In order to obtain the address of the IntPtr array, 
            // we must fix it in memory. We do this using GCHandle.
            GCHandle gch = GCHandle.Alloc(image_files_array, GCHandleType.Pinned);
            // pimage_files will point to the head of the IntPtr array.
            IntPtr pimage_files = gch.AddrOfPinnedObject();

            // Not sure what to do with you.
            // Set pimage_files as the value of the "image_files" field/
            //in_file_info.image_files = pimage_files;

            return pimage_files;
        }

        public static string[] TestAlignMethods(String pathToImagesForMontage)
        {
            string[] aligned_images_names = null;
            string[] result = new string[] { };

            try
            {
                i2kRetina.da_i2k_input_file_info in_file_info = new i2kRetina.da_i2k_input_file_info();

                // Base path null here, specific image paths defined in the GetImageFilePaths method.
                in_file_info.image_path = null;
                List<String> imageFilePaths = GetImageFilePaths(
                        pathToImagesForMontage,
                        new Regex(@"(.)+\.((jpg)|(JPG)|(TIF)|(tif)|(png)|(PNG))$")
                        );

                // This is how many images the software will process.
                in_file_info.num_images = imageFilePaths.Count;
                in_file_info.image_files = GetImageFilePathsIntPtr(imageFilePaths);

                int images_type = i2kRetina.DA_I2K_IMAGES_RETINAL;
                int layout_type = i2kRetina.DA_I2K_LAYOUT_AUTO;
                int reg_id = 0;

                Stopwatch stopwatch = Stopwatch.StartNew();
                var error_code = i2kRetina.da_i2k_start_from_new_images(in_file_info, images_type, layout_type, out reg_id, out string error_msg);

                if (error_code != i2kRetinaErrorCode.success)
                {
                    logger.Error("error_code = i2kRetina.da_i2k_start_from_new_images(in_file_info, images_type, layout_type, out reg_id, out error_msg)");
                    logger.Error(error_code);
                    logger.Error(error_msg);
                    return result;
                }

                i2kRetina.da_i2k_register_options_info reg_options = new i2kRetina.da_i2k_register_options_info();
                i2kRetina.da_i2k_default_register_options_info(ref reg_options);
                reg_options.use_distortion_correction = true;  // is it needed?

                error_code = i2kRetina.da_i2k_run_registration(reg_id, reg_options);

                if (!CheckError(reg_id, error_code))
                {
                    logger.Error("error_code = i2kRetina.da_i2k_run_registration(reg_id, reg_options);");
                    logger.Error(error_code);
                    logger.Error(error_msg);
                    return result;
                }

                int num_components;
                error_code = i2kRetina.da_i2k_how_many_components(reg_id, out num_components);

                int comp_index = 0;
                string[] image_names;
                error_code = i2kRetina.da_i2k_what_images_are_in_component(reg_id, comp_index, out image_names);


                //  Assign the option on the output image
                i2kRetina.da_i2k_output_file_info out_file_info = new i2kRetina.da_i2k_output_file_info();
                out_file_info.path = pathToImagesForMontage;
                out_file_info.prefix = @"aligned-images";
                out_file_info.extension = @"jpg";

                i2kRetina.da_i2k_output_options out_options = new i2kRetina.da_i2k_output_options();

                i2kRetina.da_i2k_build_aligned_images_options build_aligned_options = new i2kRetina.da_i2k_build_aligned_images_options();
                i2kRetina.da_i2k_default_build_aligned_images_options(ref build_aligned_options);

                string output_folder_path = null;

                error_code = i2kRetina.da_i2k_build_aligned_images(
                        reg_id,
                        out_file_info,
                        out_options,
                        build_aligned_options,
                        ref output_folder_path,
                        ref aligned_images_names)
                        ;

                if (!CheckError(reg_id, error_code))
                {
                    logger.Error("error_code = i2kRetina.da_i2k_build_aligned_images(reg_id, out_file_info, out_options, build_montage_options, out montage_file_name);");
                    logger.Error(error_code);
                    return result;
                }

                error_code = i2kRetina.da_i2k_clear_registration(reg_id);
                if (!CheckError(reg_id, error_code))
                {
                    logger.Error("error_code = i2kRetina.da_i2k_clear_registration(reg_id);");
                    logger.Error(error_code);
                    return result;
                }

                return aligned_images_names;
            }
            catch (Exception ex) {
                logger.Error("AlignMethod");
                logger.Error(ex);
                return result;
            }
        }



















        public static string TestMontageMethod(String pathToImagesForMontage,string name)
        {
            string result = string.Empty;

            Stopwatch stopwatch = Stopwatch.StartNew();

            string error_msg;

            i2kRetinaErrorCode error_code = new i2kRetinaErrorCode();

            i2kRetina.da_i2k_input_file_info in_file_info = new i2kRetina.da_i2k_input_file_info();

            // Base path null here, specific image paths defined in the GetImageFilePaths method.
            in_file_info.image_path = null;
            List<String> imageFilePaths = GetImageFilePaths(
                  pathToImagesForMontage,
                  new Regex(@"(.)+\.((jpg)|(JPG)|(TIF)|(tif))$")
                  );

            // This is how many images the software will process.
            in_file_info.num_images = imageFilePaths.Count;
            in_file_info.image_files = GetImageFilePathsIntPtr(imageFilePaths);

            int images_type = i2kRetina.DA_I2K_IMAGES_RETINAL;
            int layout_type = i2kRetina.DA_I2K_LAYOUT_QUADRATIC;

            /* primitive stress to make sure no large memory leaks */
            int loops = 1;
           
            for (int loop_n = 0; loop_n < loops; loop_n++)
            {
                Process proc = Process.GetCurrentProcess();
                long amt = proc.PrivateMemorySize64;

                long amtKB = amt / 1024;
                long amtMB = amtKB / 1024;

               LogHelper.LogInfo.WriteInfo($"\nAmount of {amtMB} MB Used At Start of #{loop_n} of {loops} iterations\n");
                int reg_id = 0;
                error_code = i2kRetina.da_i2k_start_from_new_images(in_file_info, images_type, layout_type, out reg_id, out error_msg);

                if (error_code != i2kRetinaErrorCode.success)
                {
                    logger.Error("Failed to start a new registration session");
                    logger.Error(error_msg);
                    return result;
                }

                i2kRetina.da_i2k_register_options_info reg_options = new i2kRetina.da_i2k_register_options_info();
                i2kRetina.da_i2k_default_register_options_info(ref reg_options);
                reg_options.use_distortion_correction = true;  // is it needed?

                error_code = i2kRetina.da_i2k_run_registration(reg_id, reg_options);

                if (!CheckError(reg_id, error_code))
                {
                    logger.Error("error_code = i2kRetina.da_i2k_run_registration(reg_id, reg_options);");
                    logger.Error(error_code);
                    return result;
                }

                //
                //  Check generated components
                //
                int num_components;
                error_code = i2kRetina.da_i2k_how_many_components(reg_id, out num_components);

                int comp_index = 0;
                string[] image_names;
                error_code = i2kRetina.da_i2k_what_images_are_in_component(reg_id, comp_index, out image_names);

                //
                //  Generate the montage.
                //

                //  Assign the options on the formation of the montage image
                i2kRetina.da_i2k_build_montage_options build_montage_options = new i2kRetina.da_i2k_build_montage_options();
                build_montage_options.blend_option = i2kRetina.DA_I2K_BLEND_FULL;
                build_montage_options.attempt_to_crop = false;
                build_montage_options.area_pct_for_crop = i2kRetina.DA_I2K_CROP_AREA_PCT_DEFAULT;


                //  Assign the option on the output image
                i2kRetina.da_i2k_output_file_info out_file_info = new i2kRetina.da_i2k_output_file_info();
                out_file_info.path = pathToImagesForMontage + "\\montage-images\\";
                out_file_info.prefix = @"montage_" + name + @"_" + DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
                out_file_info.extension = @"jpg";
                out_file_info.shall_overwrite_if_exists = true;

                i2kRetina.da_i2k_output_options out_options = new i2kRetina.da_i2k_output_options();

                //  Build the actual montage

                // Need strings first, intptrs second.
                string montage_file_name;

                error_code = i2kRetina.da_i2k_build_montage(reg_id, out_file_info, out_options, build_montage_options, out montage_file_name);

                if (!CheckError(reg_id, error_code))
                {
                    logger.Error("error_code = i2kRetina.da_i2k_build_montage(reg_id, out_file_info, out_options, build_montage_options, out montage_file_name);");
                    logger.Error(error_code);
                    return result;
                }

                stopwatch.Stop();
               LogHelper.LogInfo.WriteInfo("Milliseconds Elapsed =  " + stopwatch.ElapsedMilliseconds);
               LogHelper.LogInfo.WriteInfo("Done!\n");

                error_code = i2kRetina.da_i2k_clear_registration(reg_id);
                if (!CheckError(reg_id, error_code))
                {
                    logger.Error("error_code =da_i2k_clear_registration(reg_id);");
                    logger.Error(error_code);
                    return result;
                }

                result = montage_file_name;

            } /*end the loop */
            return result;
        }




        public static string[] TestAlignMethods1(String pathToRetinaMontageImages,string yyymmddd)
        {
            string[] aligned_images_names = null;

            try
            {
                string error_msg;

                i2kRetinaErrorCode error_code = new i2kRetinaErrorCode();

                i2kRetina.da_i2k_input_file_info in_file_info = new i2kRetina.da_i2k_input_file_info();

                // Base path null here, specific image paths defined in the GetImageFilePaths method.
                in_file_info.image_path = null;
                List<String> imageFilePaths = GetImageFilePaths(
                      pathToRetinaMontageImages,
                      new Regex(@"(.)+\.((jpg)|(JPG)|(TIF)|(tif)|(png)|(PNG))$")
                      );

                if (imageFilePaths == null || imageFilePaths.Count() == 0)
                {
                    logger.Error("Trouble finding images to process. Quitting.");
                    System.Environment.Exit(0);
                }

                // This is how many images the software will process.
                in_file_info.num_images = imageFilePaths.Count;
                in_file_info.image_files = GetImageFilePathsIntPtr(imageFilePaths);

                int images_type = i2kRetina.DA_I2K_IMAGES_RETINAL;
                int layout_type = i2kRetina.DA_I2K_LAYOUT_AUTO;
                int reg_id = 0;

                Stopwatch stopwatch = Stopwatch.StartNew();
                error_code = i2kRetina.da_i2k_start_from_new_images(in_file_info, images_type, layout_type, out reg_id, out error_msg);

                if (error_code != i2kRetinaErrorCode.success)
                {
                    logger.Error(error_msg);
                    return aligned_images_names;
                }

                i2kRetina.da_i2k_register_options_info reg_options = new i2kRetina.da_i2k_register_options_info();
                i2kRetina.da_i2k_default_register_options_info(ref reg_options);
                reg_options.use_distortion_correction = true;  // is it needed?

                error_code = i2kRetina.da_i2k_run_registration(reg_id, reg_options);

                if (!CheckError(reg_id, error_code))
                {
                    return aligned_images_names;
                }

                //
                //  Check generated components
                //
                int num_components;
                error_code = i2kRetina.da_i2k_how_many_components(reg_id, out num_components);

                int comp_index = 0;
                string[] image_names;
                error_code = i2kRetina.da_i2k_what_images_are_in_component(reg_id, comp_index, out image_names);


                //  Assign the option on the output image
                i2kRetina.da_i2k_output_file_info out_file_info = new i2kRetina.da_i2k_output_file_info();
                out_file_info.path = pathToRetinaMontageImages + $@"\{yyymmddd.Substring(0, 8)}\{yyymmddd}";
                out_file_info.prefix = @"aligned-images";
                out_file_info.extension = @"jpg";

                i2kRetina.da_i2k_output_options out_options = new i2kRetina.da_i2k_output_options();

                i2kRetina.da_i2k_build_aligned_images_options build_aligned_options = new i2kRetina.da_i2k_build_aligned_images_options();
                i2kRetina.da_i2k_default_build_aligned_images_options(ref build_aligned_options);


                string output_folder_path = null;

                error_code = i2kRetina.da_i2k_build_aligned_images(
                       reg_id,
                       out_file_info,
                       out_options,
                       build_aligned_options,
                       ref output_folder_path,
                       ref aligned_images_names)
                       ;

                if (!CheckError(reg_id, error_code))
                {
                    String errMsg = i2kRetina.da_i2k_get_error_message(reg_id);
                    logger.Error(errMsg);
                    return aligned_images_names;
                }

                error_code = i2kRetina.da_i2k_clear_registration(reg_id);
                if (!CheckError(reg_id, error_code))
                {
                    return aligned_images_names;
                }


                stopwatch.Stop();
                LogHelper.LogInfo.WriteInfo("Milliseconds Elapsed =  " + stopwatch.ElapsedMilliseconds);

                LogHelper.LogInfo.WriteInfo("Completely Done. Press ANY Key to finish.");
            }
            catch (Exception ex) {
                logger.Error(ex);
            }

            return aligned_images_names;
        }
    }
}