﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestI2K.WSFundus
{
    public class TaskTest
    {
        public string TaskID { get; private set; }

        public TaskTest(string seed)
        {
            TaskID = seed;
        }

       

       
    }
}
