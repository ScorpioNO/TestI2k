﻿using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestI2K
{
    public class LogHelper
    {
        private ILog _log4Net = null;

        private LogHelper(ILog log4NetInstance)
        {
            _log4Net = log4NetInstance;
        }

        public static LogHelper GetLogger(string configName)
        {
            var logger = LogManager.GetLogger(configName);
            if (logger == null)
            {
                throw new ArgumentException(string.Format("No logger configuration named '{0}' was found in the configuration.", configName), "configName");
            }
            return new LogHelper(logger);
        }


        public static LogHelper Default
        {
            get
            {
                return GetLogger("Logger");
            }
        }

        public static LogHelper LogInfo
        {
            get
            {
                return GetLogger("logInfo");
            }
        }

        public static LogHelper LogException
        {
            get
            {
                return GetLogger("logException");
            }
        }





        public void WriteInfo(object message)
        {
            _log4Net.Info(message);
        }


        public void WriteWarning(object message)
        {
            _log4Net.Warn(message);
        }


        public void WriteWarning(object message, System.Exception exception)
        {
            _log4Net.Warn(message, exception);
        }


        public void WriteError(object message)
        {
            _log4Net.Error(message);
        }


        public void WriteError(object message, System.Exception exception)
        {
            _log4Net.Error(message, exception);
        }


        public void WriteFatal(object message)
        {
            _log4Net.Fatal(message);
        }


        public void WriteFatal(object message, System.Exception exception)
        {
            _log4Net.Fatal(message, exception);
        }

        //删除日志
        public void DeleteLog()
        {
            string logDirPath = Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location), "Log");
            if (!Directory.Exists(logDirPath)) return;
            int days = 30;
            foreach (string filePath in Directory.GetFiles(logDirPath))
            {
                DateTime dt;
                DateTime.TryParse(Path.GetFileNameWithoutExtension(filePath).Replace(@"Log\", ""), out dt);
                if (dt.AddDays(days).CompareTo(DateTime.Now) < 0)
                {
                    File.Delete(filePath);
                }
            }
        }
    }
}
