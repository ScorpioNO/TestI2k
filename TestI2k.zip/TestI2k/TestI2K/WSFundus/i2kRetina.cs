﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace TestI2K.WSFundus
{
    public class i2kRetina
    {
        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////
        //
        //  Constant values and structures
        //
        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////

        //  Options on the images type.  Users may not work with retinal
        //  images unless they have a license to the i2k Retina product.
        public const int DA_I2K_IMAGES_RETINAL = 0;
        public const int DA_I2K_IMAGES_PHOTOGRAPHIC = 1;
        public const int DA_I2K_IMAGES_NON_PHOTOGRAPHIC = 2;
        public const int DA_I2K_IMAGES_MULTI_MODAL = 3;

        //  Here are the options on the layout of the images.  These are
        //  ignored for retinal images.
        //
        //  By choosing "Auto", the user is telling the software to
        //  automatically select between the next three.  Among these three,
        //  "Planar" causes the construction of the montage/alignment on a
        //  planar surface.  "Cylindrical" causes the construction of the
        //  montage/alignment on a cylindrical surface, which is then remapped
        //  to form the final flat image.  "Reposition" allows only
        //  translation between images, which seems like it would be a crazy
        //  thing to do, but it works in a surprising number of cases because
        //  of the effectiveness of our seam selection in forming a montage.
        //  (Hence, it is most useful for montaging.)  Examples where it works
        //  well include images with a lot of foreground water and background
        //  sky.
        //
        //  The other three models are more commonly used for building an
        //  aligned sequence of images. Thus, ignoring Auto, there are six
        //  layouts available.  As a hierarchy, they go from similarity to
        //  affine to homography to planar, with cylindrical being somewhat
        //  separate.  The difference between homography and planar is that
        //  planar includes radial-lens distortion terms, one for each image
        //  that is being combined through the Montage or Align functionality.
        //  Cylindrical can be quite useful as well for montaging, but
        //  although Cylindrical is also allowed for building a sequence of
        //  aligned images, it is perhaps less useful --- it is most effective
        //  when the images are spread out and together cover an area much
        //  larger than that of a single image.
        //
        //  Mathematical details of these layout models are described in a
        //  separate document distributed with the software.
        public const int DA_I2K_LAYOUT_AUTO = 0;
        public const int DA_I2K_LAYOUT_PLANAR = 1;
        public const int DA_I2K_LAYOUT_CYLINDRICAL = 2;
        public const int DA_I2K_LAYOUT_REPOSITION = 3;
        public const int DA_I2K_LAYOUT_SIMILARITY = 4;
        public const int DA_I2K_LAYOUT_AFFINE = 5;
        public const int DA_I2K_LAYOUT_HOMOGRAPHY = 6;
        public const int DA_I2K_LAYOUT_QUADRATIC = 7;

        //  Options on cropping when outputing aligned images.
        //
        public const int DA_I2K_CROP_NONE = 1;            // no crop
        public const int DA_I2K_CROP_INTERSECTION = 2;    // crop to the intersection of all images (if possible)
        public const int DA_I2K_CROP_USE_TARGET = 3;      // crop to the area of a target image

        //  Default value for the quality of the jpeg output (when jpeg is
        //  chosen).  Higher values (up to 100) indicate higher quality but
        //  larger, less-compressed files.
        //
        public const int DA_I2K_JPEG_QUALITY_DEFAULT = 87; //92;//

        //  Options on blending when montaging.  Full blend is the default.
        //  Feathered blending involves a weighted averaging of the images in
        //  the overlap region.     
        public const int DA_I2K_BLEND_FULL = 0;
        public const int DA_I2K_BLEND_FEATHERED = 1;
        public const int DA_I2K_BLEND_NONE = 2;

        //  Default crop area ratio for montaging.  See discussion below.
        public const int DA_I2K_CROP_AREA_PCT_DEFAULT = 70;

        //  Default value for the trade-off between planar and cylindrical in
        //  auto layout for montage
        public const int DA_I2K_LAYOUT_PREF_DEFAULT = 50;
        public const string DllPath = "C:\\Users\\HuiMu06\\Downloads\\i2kRetina-3.6.3-x32-devel\\Unicode-libs\\da_i2k_retina_v2.dll";
        //public const string DllPath = "da_i2k_retina_v2.dll";

        // standard Windows structures
        [StructLayout(LayoutKind.Sequential)]
        public struct da_i2k_input_file_info
        {
            /// <summary>
            /// image_path -  The full path to the image directory.  This path must
            /// exist, but all of the images need not be in this directory.
            /// The code cd's into this directory to read the images.
            /// </summary>
            [MarshalAs(UnmanagedType.LPTStr)]
            public string image_path;
            /// <summary>
            /// image_files - The names of the image files, specified relative to
            /// the image_path.  Note that if the image_path is
            /// empty, then these image_files must be full paths or
            /// must be part in the current working directory.
            /// 
            /// Refer to http://social.msdn.microsoft.com/Forums/en-US/csharpgeneral/thread/8a84708d-255b-4010-94d8-cdb5205a0a0c/
            /// about how to convert string array to this IntPtr
            ///
            /// </summary>        
            public IntPtr image_files;
            /// <summary>
            /// num_images -  The number of images in the image_files array.
            /// </summary>
            public int num_images;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct da_i2k_register_options_info
        {
            /// <summary>
            ///  aggressive_registration_pref - Increase this value when registering a small set of
            ///  difficult-to-register images that you know
            ///  should be registered.  Value range is between 
            ///  [1, 10].  Default value is 1. 
            /// </summary>
            public int aggressive_registration_pref;
            /// <summary>
            ///  layout_pref_for_auto -  Only used for AUTO layout; provides balance
            ///  between planar (0) and cylindrical (100);
            ///  range in [0, 100].  Never used for retinal images.
            /// </summary>
            public int layout_pref_for_auto;
            /// <summary>
            /// use_distortion_correction - When set, the software will apply a
            /// final mapping to attempt to reduce the overall distortion.  
            /// This is ignored for REPOSTION, SIMILARITY and AFFINE layouts.
            /// Users should usually leave this turned on unless intending to build 
            /// an aligned set of images that are cropped to a particular
            /// target image (using DA_I2K_CROP_USE_TARGET).
            /// </summary>        
            [MarshalAs(UnmanagedType.I1)]
            public bool use_distortion_correction;
        }

        //  The following are the options for controlling the aligned image
        //  output
        //
        //  crop_option - DA_I2K_CROP_NONE for no cropping;
        //                DA_I2K_CROP_INTERSECTION to crop the aligned
        //                images to their common area (so no "jumping
        //                around" occurs when playing the images in an
        //                animation), and DA_I2K_CROP_USE_TARGET to use crop
        //                everything outside the area of the target image.
        //
        //   use_illumination_correction - when set, the software corrects the
        //                 illumination between images as best it can; often
        //                 this is set to false for aligned images
        //   
        [StructLayout(LayoutKind.Sequential)]
        public struct da_i2k_build_aligned_images_options
        {
            public int  crop_option;
            [MarshalAs(UnmanagedType.I1)]
            public bool use_illumination_correction;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct da_i2k_build_montage_options
        {
            /// <summary>       
            /// DA_I2K_BLEND_FULL, DA_I2K_BLEND_FEATHERED or DA_I2K_BLEND_NONE.  
            /// FULL includes illumination correction, seam selection and vignetting, 
            /// and it is not available for non-photographic images.
            /// FEATHERED includes only seam_selection and weighted blending.
            /// </summary>
            public int blend_option;
            /// <summary>
            ///   
            /// </summary>
            [MarshalAs(UnmanagedType.I1)]
            public bool attempt_to_crop;
            /// <summary>
            /// Cropping of the montage always finds the largest axis-aligned 
            /// rectangle that fits inside the montage.  By specifying this 
            /// parameter, the user controls whether or not the cropping rectangle is
            /// accepted (and the montage is therefore cropped).  If the area of the 
            /// cropped rectangle, as a percentage of the area (number of pixels) of the
            /// full, uncropped montage, is above the value of this parameter, the montage 
            /// is cropped.  The range is 0 to 100.  No cropping occurs for retinal images
            /// and no cropping occurs if attempt_to_crop is false. 
            /// </summary>        
            public int area_pct_for_crop;
            [MarshalAs(UnmanagedType.I1)]
            public bool enforce_illum_correction;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct da_i2k_output_file_info
        {
            /// <summary>       
            /// Path to the location to write the output files.  
            /// If this is not an absolute path, then it is relative to
            /// the current working directory.  If necessary,
            /// directories along the path will be created.
            /// </summary>
            [MarshalAs(UnmanagedType.LPTStr)]
            public string path;
            /// <summary>
            /// Prefix to add to the name of each output file.
            /// Additions will be made to this prefix for the
            /// output file names by the align tool.
            /// By default, if this field is empty, use 
            /// "mosaic" for mosaic image, "align" for aligned output
            /// folder, and "mosaic-sequence" for sequence of mosaics
            /// output.
            /// </summary>
            [MarshalAs(UnmanagedType.LPTStr)]
            public string prefix;
            /// <summary>
            /// Extension to add to the name of each output file.
            /// This extension is important because it dictates
            /// the output file format.  If the user does not choose
            /// the format, it will be chosen automatically.  The
            /// first choice will be to match the format of the input
            /// images (assuming they are all the same).  The second
            /// choice will be to handle the output format best.  If
            /// the user has specified the output format, then the
            /// software may over-ride, anyway.  For example, if jpeg
            /// is requested when 16-bit output is required, then the
            /// output will be tif or png.
            /// </summary>
            [MarshalAs(UnmanagedType.LPTStr)]
            public string extension;
            /// <summary>
            /// A boolean flag to indicate whether to generate 
            /// a unqiue file / folder name or not. When it is false, 
            /// the name is composed from the three fields: path, prefix
            /// and extension. When it is true,  a unqiue string based 
            /// on the first and the last file name of registered images
            /// will be generated. 
            /// This flag was added with version 2.3.5.  The default 
            /// value is false, which is *different* from the previous 
            /// behavior. 
            /// </summary>
            [MarshalAs( UnmanagedType.I1 )]
            public bool add_unique_postfix;
            /// <summary>
            /// A boolean flag to indicate whether to overwrite
            /// if the file / folder already exists.It will overwrite 
            /// if this flag is true.  Otherwise, it will append '-' mark
            /// and a number at the end( but before extension).  The number
            /// starts at 1 until it finds a name that does not exist.
            /// This flag was added with version 2.3.5.  The default 
            /// value is true. 
            /// </summary>
            [MarshalAs(UnmanagedType.I1)]
            public bool shall_overwrite_if_exists;
        }

        //  Initialize the da_i2k_output_file_info struct with reasonable default values. 
        //  Currently, the values are:
        //      file_info.add_unique_postfix = false;
        //      file_info.shall_overwrite_if_exists = false;
        //  The other values are set to NULL. 
        [DllImport(DllPath, EntryPoint = "da_i2k_default_output_file_info", CallingConvention = CallingConvention.Cdecl)]
        public static extern void da_i2k_default_output_file_info(
            [MarshalAs(UnmanagedType.Struct)]
            ref da_i2k_output_file_info    file_info
            );

        [StructLayout(LayoutKind.Sequential)]
        public struct da_i2k_output_options
        {
            /// <summary>
            /// max_linear_output_dim - The maximum output dimension, in pixels,
            /// of an aligned image or of a montage.  Set this to a value less 
            /// than or equal to 0 for full resolution
            /// </summary>
            public int max_linear_output_dim;
            /// <summary>
            /// Downscale the width of the output pixels by
            /// this size.  Set this to less than or equal to 1.0 for full_resolution.
            /// As an example, setting it to 2.0 produces a half size
            /// in each dimension, and 4x fewer pixels overall.
            /// </summary>
            public double output_pixel_scaling;
            /// <summary>
            /// Only applied for PNG and TIFF formats.
            /// </summary>
            [MarshalAs(UnmanagedType.I1)]
            public bool save_alpha_channel;
            /// <summary>
            /// Ignored for images labeled as non-photographic.  
            /// If the user wants to create ordinary aligned images or montages, 
            /// this parameter should be set to false, which is the default.  If
            /// this parameter is true, the software will create as output 16-bit 
            /// images where each pixel's value is roughly proportional to the amount 
            /// (radiance) of light that fell on the camera to form each pixel.
            /// This is somewhat akin to HDR and in many cases it looks like an 
            /// image prior to gamma correction.
            /// </summary>
            [MarshalAs(UnmanagedType.I1)]
            public bool create_radiance_image;
        }

        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////
        //
        //  Phase 1: Initialize
        //
        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////

        //
        //  Get the expected license file path.  This path is generated based
        //  on which operating system is in use and is the path used by the
        //  installer when i2k Align and i2k Retina are downloaded and
        //  installed.  Unless the user has a very good reason (and has moved
        //  the state file!), s/he should use this expected license path!
        //  The expected license folder for various systems are:
        //    - On Mac OSX, it is /Users/Shared/i2kAlign (Or /Users/Shared/i2kRetina for i2k Retina)
        //    - On Linux, it is $HOME/.i2k 
        //    - On Windows, there are two tries:
        //        a) If a piece of Windows registry is set, use it. 
        //        b) Otherwise, try current working directory.
        //
        //  The calling function owns the returned C-style string and is
        //  responsible for deleting it.  The return string can be supplied 
        //  to da_i2k_initialize().  There is no need to call this function 
        //  if the path is already known or specified. 
        // 
        [DllImport(DllPath, EntryPoint = "da_i2k_expected_license_path", CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr _da_i2k_expected_license_path();

        public static string da_i2k_expected_license_path()
        {
            IntPtr path = _da_i2k_expected_license_path();
            return get_str_from_intptr(ref path);
        }



        [DllImport("da_i2k_retina_v2.dll", EntryPoint = "da_i2k_deactivate", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_deactivate(
         out IntPtr error_msg
         );
        public static i2kRetinaErrorCode da_i2k_deactivate(
            out string error_msg
            )
        {
            IntPtr error_msg_ptr;
            int ret = _da_i2k_deactivate(out error_msg_ptr);
            //  Convert to string object
            error_msg = get_str_from_intptr(ref error_msg_ptr);
            return (i2kRetinaErrorCode)ret;
        }



        [DllImport("da_i2k_retina_v2.dll", EntryPoint = "da_i2k_activate", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_activate(
          string activationcode,
          out IntPtr error_msg
          );
        public static i2kRetinaErrorCode da_i2k_activate(
            string activationcode,
            out string error_msg
            )
        {
            IntPtr error_msg_ptr;
            int ret = _da_i2k_activate(activationcode, out error_msg_ptr);
            //  Convert to string object
            error_msg = get_str_from_intptr(ref error_msg_ptr);
            return (i2kRetinaErrorCode)ret;
        }



        //  Before doing anything at all, the caller must initialize the
        //  software.  This requires specifying a path to the folder where all
        //  licensing and trial mode information is stored.  The return error
        //  code (see da_error_code.h) will tell the caller whether the
        //  software is ready to do real work.  The expected path to the
        //  license file, specific to the operating system, can be retrieved
        //  using the utility function da_i2k_expected_license_path.  After
        //  calling this function, the da_i2k_available_functions utility
        //  may be called to obtain the information on what functionality 
        //  is allowed using the current license and on the state of the trial, 
        //  if the software is in trial mode.
        //
        //  Input arguments:
        //
        //    license_file_path      -  the absolute path to the folder where license 
        //                              and .state files are located.
        //
        //    trace_level            -  Specify the trace level for detailed
        //                              output during the initialization process.
        //                              It can be used with the next argument to get 
        //                              detailed output from the library
        //                              throughout the computation when it is needed. 
        //                              The default value is 0 and currently all values are 
        //                              treated as 0.
        //
        //    file_for_cout          -  The optional file_for_cout is the file to which std::cout
        //                              intermediate output is directed.  std::cerr is not currently
        //                              redirected.  No facility is provided for reverting std::cout back
        //                              to its original state. This point can be set to 0(NULL) if the 
        //                              redirection is not desired. 
        //  Output arguments:
        //
        //    Return value is an integer indicating the success status of the function call. 
        //    If the return code is not 0 (success), the error_msg will contain
        //    the error message for further diagnose the issue. 
        //
        //  This function should be called exactly once for a program run. It
        //  does not need to be called again, even after clearing and all
        //  registrations.
        //
        //////////////////////////////////////////////////////////////////////
        [DllImport(DllPath, EntryPoint = "da_i2k_initialize", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_initialize(
            IntPtr license_file_path,
            int trace_level,
            [MarshalAs(UnmanagedType.LPTStr)]
            string                              file_for_cout,
            out IntPtr error_msg
            );

        public static i2kRetinaErrorCode da_i2k_initialize(
            string license_file_path,
            int trace_level,
            string file_for_cout,
            out string error_msg
            )
        {
            IntPtr error_msg_ptr;
            IntPtr str_ptr = get_intptr_from_str(license_file_path);
            int ret = _da_i2k_initialize(str_ptr, trace_level, file_for_cout, out error_msg_ptr);
            //  Convert to string object
            error_msg = get_str_from_intptr(ref error_msg_ptr);
            //  Release unmanaged string pointer memory
            free_intptr_memory(str_ptr);

            return (i2kRetinaErrorCode)ret;
        }

        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////
        //
        //  Phase 2: Start a new registration
        //
        //  Create a new registration session in one of two ways: (1) by
        //  specifying a new set of images to register, or (2) by reloading a
        //  previously-saved registration.  For (1), both the image type and
        //  the layout type must be specified (these are described immediately
        //  below).  When starting from an existing registration or adding to
        //  one, all image sets will have the same image type and layout.  For
        //  retinal images none of this is a concern since all fundus, ICG,
        //  SLO and FA images are treated as retinal.
        //
        //  A registration id is never re-used throughout this computation.
        //
        //  Important note: while multiple registration sessions are allowed,
        //  it is strongly recommended that each session be cleared (using
        //  da_i2k_clear_registration) before starting a new session.  This
        //  will save on memory.
        //
        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////

        //
        //  Create an empty registration session.  The 
        //  images_type and layout_type must be specified
        //  here.  The layout type is ignored for retinal images.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_start_reg_session", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_start_reg_session(
            int in_images_type,
            int in_layout_type,
            out int reg_id,
            out IntPtr error_msg
            );

        public static i2kRetinaErrorCode da_i2k_start_reg_session(
            int in_images_type,
            int in_layout_type,
            out int reg_id,
            out string error_msg
            )
        {
            IntPtr error_msg_ptr = IntPtr.Zero;
            int ret = _da_i2k_start_reg_session(in_images_type, in_layout_type, out reg_id, out error_msg_ptr);
            error_msg = Marshal.PtrToStringUni(error_msg_ptr);
            return (i2kRetinaErrorCode)ret;
        }


        //
        //  Create a registration session from a set of input files to be
        //  registered.  The images_type and layout_type must be specified
        //  here.  The layout type is ignored for retinal images.
        //
        //  An integer registration id is returned as a reference parameter.
        //  This must be passed to all subsequent functions that apply to the
        //  same registration computation.
        //
        //  Deprecated: this function is kept for backward-compatibility.  It essentially 
        //  calls two functions in succession:
        //    da_i2k_start_reg_session
        //    da_i2k_add_images
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_start_from_new_images", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_start_from_new_images(
            [MarshalAs(UnmanagedType.Struct)]
            da_i2k_input_file_info              in_file_info,
            int images_type,
            int layout_type,
            out int reg_id,
            out IntPtr error_msg
            );

        public static i2kRetinaErrorCode da_i2k_start_from_new_images(
            da_i2k_input_file_info in_file_info,
            int images_type,
            int layout_type,
            out int reg_id,
            out string error_msg
            )
        {
            IntPtr error_msg_ptr;
            int ret = _da_i2k_start_from_new_images(in_file_info, images_type, layout_type, out reg_id, out error_msg_ptr);
            error_msg = Marshal.PtrToStringUni(error_msg_ptr);
            return (i2kRetinaErrorCode)ret;
        }
        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////
        //
        //   Phase 3: Adding or load images to registration computations
        //   before the computation starts.  More sophisticated options are
        //   available in the Pro version of the software.  These are
        //   explained in the separate Pro header.
        //
        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////

        //
        //  Add images before the start of the (next call to the) registration
        //  process.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_add_images", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_add_images(
            int reg_id,
            [MarshalAs(UnmanagedType.Struct)]
            da_i2k_input_file_info              in_file_info
            );

        public static i2kRetinaErrorCode da_i2k_add_images(
            int reg_id,
            da_i2k_input_file_info in_file_info
            )
        {
            int ret = _da_i2k_add_images(reg_id, in_file_info);
            return (i2kRetinaErrorCode)ret;
        }
        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////
        //
        //  Phase 4:  Masking / ROI
        //
        //  The default is to compute a convex mask for each retinal image and
        //  to compute no mask for photographic and non-photographic images.
        //  These masks are based on finding the (more or less) homogeneous
        //  regions on the image periphery that appear to contain no data of
        //  interest.  The user change this default behavior with the two
        //  functions listed below.
        //
        //  There are other possibilities beyond the automatic mask
        //  computation, however.  These involve setting circular or
        //  axis-aligned rectangular ROI, setting a binary mask, either one
        //  for each image or one for all images, or setting the color of 
        //  image background. These functions are only available in Pro header. 
        //
        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////

        //
        // Do not use any mask, i.e., whole image is ROI, for any image in the reg session.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_set_all_roi_use_full_image", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_set_all_roi_use_full_image(int reg_id);

        public static i2kRetinaErrorCode da_i2k_set_all_roi_use_full_image(int reg_id)
        {
            int ret = _da_i2k_set_all_roi_use_full_image(reg_id);
            return (i2kRetinaErrorCode)ret;
        }
        //
        // Do not use any mask, i.e., whole image is ROI, for one image.
        // An example usage is to remove ROI after registration is finished and 
        // hence the whole image is used in output phrase
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_set_image_roi_use_full_image", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_set_image_roi_use_full_image(
            int reg_id,
            [MarshalAs(UnmanagedType.LPTStr)]
            string                              image_file_name
            );

        public static i2kRetinaErrorCode da_i2k_set_image_roi_use_full_image(
            int reg_id,
            string image_file_name
            )
        {
            int ret = _da_i2k_set_image_roi_use_full_image(reg_id, image_file_name);
            return (i2kRetinaErrorCode)ret;
        }
        //
        // Automatically compute mask for all images.  
        // The algorithm is designed to work on retinal fundus images, but 
        // the implementation is quite general-purpose and may work on other images. 
        // It assumes ROI is surrounded by homogeous region in dark/bright color and 
        // the boundary is mostly composed of line segments and arc segments.
        // Setting should_compute_mask to false is equivalent to use full image. 
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_set_all_roi_compute_mask", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_set_all_roi_compute_mask(
            int reg_id,
            bool should_compute_mask
            );

        public static i2kRetinaErrorCode da_i2k_set_all_roi_compute_mask(
            int reg_id,
            bool should_compute_mask
            )
        {
            int ret = _da_i2k_set_all_roi_compute_mask(reg_id, should_compute_mask);
            return (i2kRetinaErrorCode)ret;
        }
        //
        // Automatically compute mask for one image
        // The algorithm is designed to work on retinal fundus images, but 
        // the implementation is quite general-purpose and may work on other images.
        // It assumes ROI is surrounded by homogeous region in dark/bright color and 
        // the boundary is mostly composed of line segments and arc segments.
        // Setting should_compute_mask to false is equivalent to use full image. 
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_set_image_roi_compute_mask", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_set_image_roi_compute_mask(
            int reg_id,
            [MarshalAs(UnmanagedType.LPTStr)]
            string                              image_file_name,
            bool should_compute_mask
            );

        public static i2kRetinaErrorCode da_i2k_set_image_roi_compute_mask(
            int reg_id,
            [MarshalAs(UnmanagedType.LPTStr)]
            string                              image_file_name,
            bool should_compute_mask
            )
        {
            int ret = _da_i2k_set_image_roi_compute_mask(reg_id, image_file_name, should_compute_mask);
            return (i2kRetinaErrorCode)ret;
        }

        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////
        //
        //  Phase 5:  The registration process
        //
        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////

        //
        //  Initialize the da_i2k_register_options_info struct with reasonable default values. 
        //  Currently, the values are:
        //      options.aggressive_registration_pref = 1
        //      options.use_distortion_correction = true;
        //      options.layout_pref_for_auto = DA_I2K_LAYOUT_PREF_DEFAULT;
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_default_register_options_info", CallingConvention = CallingConvention.Cdecl)]
        public static extern void da_i2k_default_register_options_info(
            [MarshalAs(UnmanagedType.Struct)]
            ref da_i2k_register_options_info    options
            );

        //
        //  Run registration.  The return argument tells whether all images or
        //  some images have been registered to each other.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_run_registration", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_run_registration(
            int reg_id,
            [MarshalAs(UnmanagedType.Struct)]
            da_i2k_register_options_info        options
            );

        public static i2kRetinaErrorCode da_i2k_run_registration(
            int reg_id,
            [MarshalAs(UnmanagedType.Struct)]
            da_i2k_register_options_info        options
            )
        {
            int ret = _da_i2k_run_registration(reg_id, options);
            return (i2kRetinaErrorCode)ret;
        }

        //
        //  Inquire whether image registration has been run on *all* images.  
        //  In other words, it shall return true immediately following call to 
        //  da_i2k_run_registration. If one or more than one image(s) has 
        //  been added afterwards, however, this call shall return false.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_has_registration_been_run_on_all_images", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_has_registration_been_run_on_all_images(
            int reg_id,
            out bool has_been_run
            );

        public static i2kRetinaErrorCode da_i2k_has_registration_been_run_on_all_images(
            int reg_id,
            out bool has_been_run
            )
        {
            int ret = _da_i2k_has_registration_been_run_on_all_images(reg_id, out has_been_run);
            return (i2kRetinaErrorCode)ret;
        }

        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////
        //
        //  Phase 7 (optional):  Components, subsets and a target image
        //
        //  The registration process produces connected components of images.
        //  In most cases, all images will be in a single connected component.
        //  The user has the option to query this information and, when there
        //  are multiple components, to select which one to use.  The default
        //  is the component containing the most images.
        //
        //  Within a component, the user can select a target image on which
        //  the final montage or aligned image sequence will be centered.
        //  This image will be undistorted in the final montage or final
        //  output aligned image sequence and therefore, this over-rides any
        //  choice of distortion correction (in Phase 5).  At most one target
        //  image may be selected for a component.
        // 
        //  Within a component, the user can select one or more subsets for
        //  the final output of Phase 8.  These are the images that will be
        //  combined to form a montage, or that will all be mapped to the same
        //  coordinate system and output.  Multiple subsets should be selected
        //  to create a sequence of aligned montages --- each subset will be a
        //  separate montage, but the montages will be co-registered and, if
        //  the target exists, centered on the target.  Note that the target
        //  does not have to be in any subset.  The default subset is the
        //  entire component.
        //
        //  Here are a few important points about this:
        //
        //  . All selected images in all subsets must be from the same
        //    component.
        //
        //  . Each image may be in any number of subsets, although typically
        //    each image will be in one subset.
        //
        //  . In order to create output from separate components, the
        //    subset(s) must be cleared from one component before subsets from
        //    a second component are selected.
        //
        //  . Multiple subsets should only be selected if the desired output
        //    is a sequence of montages.  If the build_montage or
        //    build_aligned image sequences are chosen after specifying
        //    multiple subsets, the first subset will be used.
        //
        //  . Selecting the component is the only way to clear the subset
        //    and/or the target.
        //
        //  . Auto layout is not re-run and therefore the layout selected
        //    during the registration process is kept during all subset
        //    computations.
        //
        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////
        [DllImport(DllPath, EntryPoint = "da_i2k_how_many_components", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_how_many_components(
            int reg_id,
            out int num_components
            );

        public static i2kRetinaErrorCode da_i2k_how_many_components(
            int reg_id,
            out int num_components
            )
        {
            int ret = _da_i2k_how_many_components(reg_id, out num_components);
            return (i2kRetinaErrorCode)ret;
        }

        [DllImport(DllPath, EntryPoint = "da_i2k_what_images_are_in_component", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_what_images_are_in_component(
            int reg_id,
            int component_index,
            out IntPtr image_names,
            out int num_images_in_component
            );

        public static i2kRetinaErrorCode da_i2k_what_images_are_in_component(
            int reg_id,
            int component_index,
            out string[] image_names
            )
        {
            int num_images;
            IntPtr image_names_ptr;
            image_names = null;

            int ret = _da_i2k_what_images_are_in_component(reg_id, component_index, out image_names_ptr, out num_images);

            if (ret != (int)i2kRetinaErrorCode.success)
            {
                return (i2kRetinaErrorCode)ret;
            }

            IntPtr[] str_array = new IntPtr[num_images];
            Marshal.Copy(image_names_ptr, str_array, 0, num_images);

            image_names = new string[num_images];
            for (int i = 0; i != num_images; ++i)
            {
                image_names[i] = Marshal.PtrToStringUni(str_array[i]);
            }

            da_i2k_free_string_array(ref num_images, ref image_names_ptr);

            return (i2kRetinaErrorCode)ret;
        }
        //
        // Select the new component_index.  Resets the target and subset
        // information, even if it is the same component_index as previous.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_select_component", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_select_component(
            int reg_id,
            int component_index
            );

        public static i2kRetinaErrorCode da_i2k_select_component(
            int reg_id,
            int component_index
            )
        {
            int ret = _da_i2k_select_component(reg_id, component_index);
            return (i2kRetinaErrorCode)ret;
        }

        //
        //  Select (or reselect) the target image within the current
        //  component.  If the target image is not in the current component,
        //  no change is made.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_select_target_in_current_component", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_select_target_in_current_component(
            int reg_id,
            IntPtr target_image_file_name
            );

        public static i2kRetinaErrorCode da_i2k_select_target_in_current_component(
            int reg_id,
            string target_image_file_name
            )
        {
            IntPtr int_ptr = get_intptr_from_str(target_image_file_name);
            int ret = _da_i2k_select_target_in_current_component(reg_id, int_ptr);
            //  Release unmanged memory
            free_intptr_memory(int_ptr);
            return (i2kRetinaErrorCode)ret;
        }
        //
        //  Using the image names, find the component containing the images
        //  and then create a subset within that component.  If no component
        //  contains the subset, no changes are made.  
        //  The index to the component and to the newly added subset will 
        //  be returned after the call 
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_select_component_and_add_subset", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_select_component_and_add_subset(
            int reg_id,
            IntPtr image_names,
            int num_images_in_subset,
            out int comp_index,
            out int subset_index
            );

        public static i2kRetinaErrorCode da_i2k_select_component_and_add_subset(
            int reg_id,
            string[] image_names,
            int num_images_in_subset,
            out int comp_index,
            out int subset_index
            )
        {
            IntPtr image_names_ptr = get_intptr_from_str_array(image_names);
            int ret = _da_i2k_select_component_and_add_subset(reg_id, image_names_ptr, num_images_in_subset,
                                                               out comp_index, out subset_index);
            // Free global memory
            free_global_intptr(image_names_ptr);
            return (i2kRetinaErrorCode)ret;
        }
        //
        //  Select a new subset in the current component.  The resulting is
        //  the intersection between the component and the images specified by
        //  the image_names array.   The index to the subset will be returned 
        //  after successful call. 
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_select_subset_in_current_component", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_select_subset_in_current_component(
            int reg_id,
            IntPtr image_names,
            int num_images_in_subset,
            ref IntPtr actual_image_names,
            out int actual_num_images_in_subset,
            out int subset_index
            );

        public static i2kRetinaErrorCode da_i2k_select_subset_in_current_component(
            int reg_id,
            string[] image_names,
            ref string[] actual_image_names,
            out int subset_index
            )
        {
            IntPtr image_names_ptr = get_intptr_from_str_array(image_names);
            IntPtr actual_image_names_ptr = IntPtr.Zero;
            int actual_num_images_in_subset;
            subset_index = -1;
            actual_image_names = null;

            int ret = _da_i2k_select_subset_in_current_component(reg_id, image_names_ptr, image_names.Length,
                                                                  ref actual_image_names_ptr, out actual_num_images_in_subset,
                                                                  out subset_index);
            if (ret != (int)i2kRetinaErrorCode.success)
            {
                return (i2kRetinaErrorCode)ret;
            }

            free_global_intptr(image_names_ptr);
            actual_image_names = get_str_array_from_intptr(ref actual_image_names_ptr, ref actual_num_images_in_subset);

            return (i2kRetinaErrorCode)ret;
        }

        //
        //  How many subsets have been selected in the current component?
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_num_subsets_in_current_component", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_num_subsets_in_current_component(
            int reg_id,
            out int num_subsets
            );

        public static i2kRetinaErrorCode da_i2k_num_subsets_in_current_component(
            int reg_id,
            out int num_subsets
            )
        {
            int ret = _da_i2k_num_subsets_in_current_component(reg_id, out num_subsets);
            return (i2kRetinaErrorCode)ret;
        }

        //
        //  What images are in the specified subset in the current component.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_what_images_are_in_subset", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_what_images_are_in_subset(
            int reg_id,
            int subset_index,
            out int num_images_in_subset,
            out IntPtr image_names_in_subset
            );

        public static i2kRetinaErrorCode da_i2k_what_images_are_in_subset(
            int reg_id,
            int subset_index,
            out string[] image_names_in_subset
            )
        {
            IntPtr image_names_in_subsets_ptr;
            int num_images_in_subset;

            int ret = _da_i2k_what_images_are_in_subset(reg_id, subset_index, out num_images_in_subset,
                                                         out image_names_in_subsets_ptr);
            image_names_in_subset = get_str_array_from_intptr(ref image_names_in_subsets_ptr, ref num_images_in_subset);

            return (i2kRetinaErrorCode)ret;
        }
        //
        //  Set name prefix for subset
        //  The value of subset must be in [0, ..., num_subsets-1]
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_set_name_prefix_of_subset", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_set_name_prefix_of_subset(
            int reg_id,
            int subset_index,
            [MarshalAs(UnmanagedType.LPTStr)]
            string                              name_prefix
            );

        public static i2kRetinaErrorCode da_i2k_set_name_prefix_of_subset(
            int reg_id,
            int subset_index,
            string name_prefix
            )
        {
            int ret = _da_i2k_set_name_prefix_of_subset(reg_id, subset_index, name_prefix);
            return (i2kRetinaErrorCode)ret;
        }
        //                      
        //  Get name prefix for subset
        //  The value of subset must be in [0, ..., num_subsets-1]
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_get_name_prefix_of_subset", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_get_name_prefix_of_subset(
            int reg_id,
            int subset_index,
            out IntPtr name_prefix
            );

        public static i2kRetinaErrorCode da_i2k_get_name_prefix_of_subset(
            int reg_id,
            int subset_index,
            out string name_prefix
            )
        {
            IntPtr name_prefix_ptr;
            int ret = _da_i2k_get_name_prefix_of_subset(reg_id, subset_index, out name_prefix_ptr);
            name_prefix = get_str_from_intptr(ref name_prefix_ptr);
            return (i2kRetinaErrorCode)ret;
        }
        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////
        //
        //  Phase 8: Generate the output.  This takes a number of different
        //           potential forms, including (a) the transformations and
        //           correspondences only, (b) a montage, (c) an aligned image
        //           sequence, and (d) a sequence of montages.  The latter
        //           three include output of the transformations and
        //           correspondence, if requested.
        //
        //  Each of (b)-(d) has a different options struct.
        //
        //  Option (d) is only available in Pro header.
        //
        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////

        //
        //  Prepare to save the transformations and the inter-image matches in
        //  a user-friendly form.  This was created for users who would like
        //  this information for a separate application, *not* for saving the
        //  information for a restart of the registration (as in Phase 6),
        //  alignment or montaging computation.
        //
        //  The actual saving of the transformations and correspondences is
        //  accomplished by a call to any one of the following functions.
        //  This is not always done separately using
        //  da_i2k_save_xforms_and_matches because the final output of the
        //  images in the da_i2k_build_* functions may scale and crop the
        //  output images images in a variety of ways, and the final output
        //  transformations are scaled and shifted accordingly.
        //
        //  Folders along the path (absolute or relative) will be created as
        //  needed.  If this folder path is 0 it will be generated
        //  automatically and will be the same as the folder where the input
        //  images are stored.  Please note upon return the output folder path 
        //  will always point to a path string allocated by the library, even 
        //  in the case that output folder path has been given.  This is to 
        //  ensure the caller can always deallocate this path string without 
        //  worrying who is the owner of the string. 
        //
        //  If the xform_file_name is not provided (xform_file_name == 0), it will
        //  be generated automatically and returned to the calling function.
        //  Otherwise, the provided xform_file_name will be used.  The same 
        //  applies to match_file_name
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_prepare_to_save_xforms_and_matches", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_prepare_to_save_xforms_and_matches(
            int reg_id,
            out IntPtr output_folder_path,
            out IntPtr xform_file_name,
            out IntPtr match_file_name
            );

        public static i2kRetinaErrorCode da_i2k_prepare_to_save_xforms_and_matches(
            int reg_id,
            out string output_folder_path,
            out string xform_file_name,
            out string match_file_name
            )
        {
            IntPtr output_folder_path_ptr, xform_file_name_ptr, match_file_name_ptr;
            int ret = _da_i2k_prepare_to_save_xforms_and_matches(reg_id, out output_folder_path_ptr, out xform_file_name_ptr,
                                                                  out match_file_name_ptr);
            output_folder_path = get_str_from_intptr(ref output_folder_path_ptr);
            xform_file_name = get_str_from_intptr(ref xform_file_name_ptr);
            match_file_name = get_str_from_intptr(ref match_file_name_ptr);
            return (i2kRetinaErrorCode)ret;
        }
        //
        //  Should be called when output of the transformations and
        //  correspondences is the only output desired.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_save_xforms_and_matches_only", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_save_xforms_and_matches_only(int reg_id);

        public static i2kRetinaErrorCode da_i2k_save_xforms_and_matches_only(int reg_id)
        {
            int ret = _da_i2k_save_xforms_and_matches_only(reg_id);
            return (i2kRetinaErrorCode)ret;
        }

        //
        //  Initialize the da_i2k_output_file_info struct with reasonable default values. 
        //  Currently, the values are:
        //      options.max_linear_output_dim = 0;
        //      options.output_pixel_scaling      = 1.0;
        //      options.save_alpha_channel = false;
        //      options.create_radiance_image = false;
        //  The other values are not touched. 
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_default_output_options", CallingConvention = CallingConvention.Cdecl)]
        public static extern void da_i2k_default_output_options(
            [MarshalAs(UnmanagedType.Struct)]
            ref da_i2k_output_options                       options
            );

        //
        //  Initialize the da_i2k_build_aligned_images_options struct with reasonable default values. 
        //  Currently, the values are:
        //    options.crop_option = DA_I2K_CROP_NONE;       
        //    options.use_illumination_correction = false;  
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_default_build_aligned_images_options", CallingConvention = CallingConvention.Cdecl)]
        public static extern void da_i2k_default_build_aligned_images_options(
            [MarshalAs(UnmanagedType.Struct)]
            ref da_i2k_build_aligned_images_options         options
            );

        //
        //  The actual call to create an output sequence of align images.  It
        //  returns the output folder path, the number of images that were
        //  output, and an array containing the names of these images (without
        //  the path).
        //
        //
        // Output variables (values will be changed) :
        //   - output_folder_path
        //   - num_output_images
        //   - aligned_image_names
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_build_aligned_images", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_build_aligned_images(
            int reg_id,
            [MarshalAs(UnmanagedType.Struct)]
            da_i2k_output_file_info                 output_file_info,
            [MarshalAs(UnmanagedType.Struct)]
            da_i2k_output_options                   out_options,
            [MarshalAs(UnmanagedType.Struct)]
            da_i2k_build_aligned_images_options     aligned_options,
            out IntPtr output_folder_path,
            out int num_output_images,
            out IntPtr aligned_image_names
            );

        public static i2kRetinaErrorCode da_i2k_build_aligned_images(
            int reg_id,
            da_i2k_output_file_info output_file_info,
            da_i2k_output_options out_options,
            da_i2k_build_aligned_images_options aligned_options,
            ref string output_folder_path,
            ref string[] aligned_image_names
            )
        {
            int num_output_images;
            IntPtr output_folder_path_ptr, aligned_image_names_ptr;
            int ret = _da_i2k_build_aligned_images(reg_id, output_file_info, out_options, aligned_options,
                                                    out output_folder_path_ptr, out num_output_images, out aligned_image_names_ptr);
            output_folder_path = get_str_from_intptr(ref output_folder_path_ptr);
            aligned_image_names = get_str_array_from_intptr(ref aligned_image_names_ptr, ref num_output_images);
            return (i2kRetinaErrorCode)ret;
        }

        //////////////////////////////////////////////////////////////////////
        //
        //  build_montage
        //
        //////////////////////////////////////////////////////////////////////

        //
        //  Initialize the da_i2k_build_montage_options struct with reasonable default values. 
        //  Currently, the values are:
        //    options.blend_option = DA_I2K_BLEND_FULL;
        //    options.attempt_to_crop = true;
        //    options.area_pct_for_crop = DA_I2K_CROP_AREA_PCT_DEFAULT;
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_default_build_montage_options", CallingConvention = CallingConvention.Cdecl)]
        public static extern void da_i2k_default_build_montage_options(
            [MarshalAs(UnmanagedType.Struct)]
            ref da_i2k_build_montage_options options
            );
        //
        //  Build montage
        //  Output variables (values will be changed) :
        //    - montage_file_name
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_build_montage", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_build_montage(
            int reg_id,
            [MarshalAs(UnmanagedType.Struct)]
            da_i2k_output_file_info             output_file_info,
            [MarshalAs(UnmanagedType.Struct)]
            da_i2k_output_options               out_options,
            [MarshalAs(UnmanagedType.Struct)]
            da_i2k_build_montage_options        montage_options,
            out IntPtr montage_file_name
            );

        public static i2kRetinaErrorCode da_i2k_build_montage(
            int reg_id,
            da_i2k_output_file_info output_file_info,
            da_i2k_output_options out_options,
            da_i2k_build_montage_options montage_options,
            out string montage_file_name
            )
        {
            IntPtr montage_file_name_ptr;
            int ret = _da_i2k_build_montage(reg_id, output_file_info, out_options, montage_options, out montage_file_name_ptr);
            montage_file_name = get_str_from_intptr(ref montage_file_name_ptr);
            return (i2kRetinaErrorCode)ret;
        }
        ////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////
        //
        //  Additional utility function for individual reg session 
        //
        ////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////
        //
        //  Query the status of the computation of any particular function
        //  call.  The result is an integer in the range 0 to 100.  The
        //  current_step is a string describing the current step of the
        //  computation.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_percent_done", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_percent_done(
            int reg_id,
            out int pcnt,
            out IntPtr current_step
            );
        public static i2kRetinaErrorCode da_i2k_percent_done(
            int reg_id,
            out int pcnt,
            out string current_step
            )
        {
            IntPtr current_step_ptr;
            int ret = _da_i2k_percent_done(reg_id, out pcnt, out current_step_ptr);
            current_step = get_str_from_intptr(ref current_step_ptr);
            return (i2kRetinaErrorCode)ret;
        }
        //
        //  Tell the registration process to show intermediate, low-resolution
        //  unblended montages as a way to monitor the output.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_set_to_show_intermediate_montages", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_set_to_show_intermediate_montages(
            int reg_id,
            [MarshalAs(UnmanagedType.LPTStr)]
            string                              folder_to_write_montages
            );

        public static i2kRetinaErrorCode da_i2k_set_to_show_intermediate_montages(
            int reg_id,
            [MarshalAs(UnmanagedType.LPTStr)]
            string                              folder_to_write_montages
            )
        {
            int ret = _da_i2k_set_to_show_intermediate_montages(reg_id, folder_to_write_montages);
            return (i2kRetinaErrorCode)ret;
        }

        //
        //  Access information about the most recently generated intermediate
        //  montage.  This includes the number of aligned images and the names
        //  of these aligned images.  If
        //  da_i2k_set_to_show_intermediate_montages has not been called then
        //  montage_file_name will always be 0, but the num_aligned_images and
        //  the aligned_image_names will be filled in.
        //
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_most_recent_intermediate_montage", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_most_recent_intermediate_montage(
            int reg_id,
            out IntPtr montage_file_name,
            out int num_aligned_images,
            out IntPtr aligned_image_names
            );
        public static i2kRetinaErrorCode da_i2k_most_recent_intermediate_montage(
            int reg_id,
            out string montage_file_name,
            out string[] aligned_image_names
            )
        {
            int num_aligned_images;
            IntPtr montage_file_name_ptr, aligned_image_names_ptr;
            int ret = _da_i2k_most_recent_intermediate_montage(reg_id, out montage_file_name_ptr, out num_aligned_images,
                                                                out aligned_image_names_ptr);
            montage_file_name = get_str_from_intptr(ref montage_file_name_ptr);
            aligned_image_names = get_str_array_from_intptr(ref aligned_image_names_ptr, ref num_aligned_images);
            return (i2kRetinaErrorCode)ret;
        }
        //
        //  Access the most recent error message.  Associated with the reg_id,
        //  if none have been generated (usually when everything is fine),
        //  this will return 0.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_get_error_message", CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr _da_i2k_get_error_message(int reg_id);

        public static string da_i2k_get_error_message(int reg_id)
        {
            IntPtr error_msg_ptr = _da_i2k_get_error_message(reg_id);
            return get_str_from_intptr(ref error_msg_ptr);
        }

        //
        //  Set the level of logging output and the folder for which the log
        //  folders should be written.  Setting the log level at 3 or higher
        //  will generate a large number of intermediate images and
        //  substantially slow the computation.  If the log_out_folder is
        //  initially 0, it will use the current directory.  
        //  To distinguish logs from multiple reg sessions, the real log 
        //  output folder will be named "debug-${reg_id}" inside the 
        //  given log_output_folder. .
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_set_log_level_and_folder", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_set_log_level_and_folder(
            int reg_id,
            int level,
            [MarshalAs(UnmanagedType.LPTStr)]
            string         log_output_folder
            );

        public static i2kRetinaErrorCode da_i2k_set_log_level_and_folder(
            int reg_id,
            int level,
            [MarshalAs(UnmanagedType.LPTStr)]
            string          log_output_folder
            )
        {
            int ret = _da_i2k_set_log_level_and_folder(reg_id, level, log_output_folder);
            return (i2kRetinaErrorCode)ret;
        }

        //
        //  Immediately signal the stop of this computation. 
        //  It may take a little while to stop the multi-threaded computation 
        //  and clean up the internal state of the computation.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_halt_processing", CallingConvention = CallingConvention.Cdecl)]
        public static extern void da_i2k_halt_processing(int reg_id);

        //
        //  Get the names of the aligned images after the computation is finished.
        //  The aligned images are obtained as the current subset in the current component. 
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_get_aligned_names", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_get_aligned_names(
            int reg_id,
            out int n,
            out IntPtr image_names
            );
        public static i2kRetinaErrorCode da_i2k_get_aligned_names(
            int reg_id,
            out string[] image_names
            )
        {
            IntPtr image_names_ptr;
            int num_images;
            int ret = _da_i2k_get_aligned_names(reg_id, out num_images, out image_names_ptr);
            image_names = get_str_array_from_intptr(ref image_names_ptr, ref num_images);
            return (i2kRetinaErrorCode)ret;
        }

        //
        //  Change the jpeg compression quality on the output montage  or images. 
        //  used only when jpeg images are output. This is a positive
        //  integer less than or equal to 100. 
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_set_jpeg_compression_quality", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_set_jpeg_compression_quality(
            int reg_id,
            int jpeg_quality
            );
        public static i2kRetinaErrorCode da_i2k_set_jpeg_compression_quality(
            int reg_id,
            int jpeg_quality
            )
        {
            int ret = _da_i2k_set_jpeg_compression_quality(reg_id, jpeg_quality);
            return (i2kRetinaErrorCode)ret;
        }
        //
        ////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////
        //
        //  The rest of this header file describes a variety of utilities.
        //
        ////////////////////////////////////////////////////////////////////////
        //
        //  Set the maximum number of simultaneously threads the computation
        //  is allowed to run.  The default is the number of processors 
        //  (or cores) available, which we can determine automatically.  If
        //  the value of the max_threads parameter is 0, then the default
        //  of the max available is used.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_set_max_threads", CallingConvention = CallingConvention.Cdecl)]
        public static extern void da_i2k_set_max_threads(uint max_threads);

        //
        //  Set the maximum number of megabytes of memory to be used in the
        //  computation.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_set_max_memory", CallingConvention = CallingConvention.Cdecl)]
        public static extern void da_i2k_set_max_memory(uint max_mega_bytes);

        //
        //  Given an input image, check to see if it is in byte format,
        //  suitable for display.  If it is not then create it and save it to
        //  the specific file.  Here is a summary of the output information:
        //
        //    is_input_byte     -  set to true if and only if the input image
        //                         is in byte format
        //
        //    was_output_created - set to true if and only if an output image
        //                         was successfully written
        //
        //  Both will be false if the image could not be read.  It is not
        //  possible form them both to be "true".
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_convert_to_displayable_file", CallingConvention = CallingConvention.Cdecl)]
        public static extern void da_i2k_convert_to_displayable_file(
            [MarshalAs(UnmanagedType.LPTStr)]
            string                              in_image_name,
            [MarshalAs(UnmanagedType.LPTStr)]
            string                              out_image_name,
            out bool is_input_byte,
            out bool was_output_created
            );
        //
        //  Get the version of this library
        //  Output parameter: a C-style string.
        //
        //  This function requires a successful call to da_i2k_initialize() first.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_version_string", CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr da_i2k_version_string();

        //
        //  A convenient function to free the memory alocated for char*
        //  As it is passed by reference, the variable will be reset 
        //  to NULL/0 after the function call
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_free_string", CallingConvention = CallingConvention.Cdecl)]
        private static extern void da_i2k_free_string(
            ref IntPtr str
            );
        //
        //  A convenient function to free the memory alocated for char**
        //  As it is passed by reference, the variables (both n and names)
        //  will be reset to 0 and NULL after the function call
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_free_string_array", CallingConvention = CallingConvention.Cdecl)]
        private static extern void da_i2k_free_string_array(
            ref int n,
            ref IntPtr names
            );

        //
        //  Tell the software that the registration associated with reg_id no
        //  longer needed and may be eliminated, recovering the memory.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_clear_registration", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_clear_registration(int reg_id);
        public static i2kRetinaErrorCode da_i2k_clear_registration(int reg_id)
        {
            int ret = _da_i2k_clear_registration(reg_id);
            return (i2kRetinaErrorCode)ret;
        }
        //
        //  Eliminate all existing registrations.
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_clear_all_registrations", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_clear_all_registrations();
        public static i2kRetinaErrorCode da_i2k_clear_all_registrations()
        {
            return (i2kRetinaErrorCode)_da_i2k_clear_all_registrations();
        }

        //////////////////////////////////////////////////////////
        //
        //      Accessors
        //
        //////////////////////////////////////////////////////////

        //
        // Access the images type used for this registration
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_get_images_type", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_get_images_type(
            int reg_id,
            ref int images_type
            );
        public static i2kRetinaErrorCode da_i2k_get_images_type(
            int reg_id,
            ref int images_type
            )
        {
            return (i2kRetinaErrorCode)_da_i2k_get_images_type(reg_id, ref images_type);
        }
        //
        // Access the layout type used for this registration
        //
        [DllImport(DllPath, EntryPoint = "da_i2k_get_layout_type", CallingConvention = CallingConvention.Cdecl)]
        private static extern int _da_i2k_get_layout_type(
            int reg_id,
            ref int layout_type
            );
        public static i2kRetinaErrorCode da_i2k_get_layout_type(
            int reg_id,
            ref int layout_type
            )
        {
            return (i2kRetinaErrorCode)_da_i2k_get_layout_type(reg_id, ref layout_type);
        }
        //////////////////////////////////////////////////////////
        //
        //      Utility functions
        //
        //////////////////////////////////////////////////////////

        //
        //  Return a pointer to string from a string object.
        //  Note that the unmanged memory pointed by the returning pointer needs to be manually released
        //  by calling free_intptr_memory(IntPtr int_ptr);
        //
        public static IntPtr get_intptr_from_str(string stringVar)
        {
            return Marshal.StringToCoTaskMemUni(stringVar);
        }
        public static void free_intptr_memory(IntPtr int_ptr)
        {
            Marshal.FreeCoTaskMem(int_ptr);
        }
        //
        //  Return a string object from a pointer to string. This function will release the unmanged memory 
        //  pointed by int_ptr and reset int_ptr to NULL
        //
        public static string get_str_from_intptr(ref IntPtr int_ptr)
        {
            string str = Marshal.PtrToStringUni(int_ptr);
            da_i2k_free_string(ref int_ptr);
            return str;
        }
        //
        //  Return an array of string objects from a pointer to a 2d string array. After calling this function,
        //  the pointer memory will be released and set to NULL, and num_str will be reset to 0
        //
        public static string[] get_str_array_from_intptr(ref IntPtr str_ptr, ref int num_str)
        {
            IntPtr[] str_array = new IntPtr[num_str];
            Marshal.Copy(str_ptr, str_array, 0, num_str);

            string[] strs = new string[num_str];
            for (int i = 0; i != num_str; ++i)
            {
                strs[i] = Marshal.PtrToStringUni(str_array[i]);
            }

            da_i2k_free_string_array(ref num_str, ref str_ptr);

            return strs;
        }
        //
        //  Return a pointer to a 2d string array from an array of string objects. The pointer
        //  is global unmanged memory and needs to be released by calling
        //  free_global_intptr(int_ptr);
        //
        public static IntPtr get_intptr_from_str_array(string[] strs)
        {
            IntPtr[] str_array = new IntPtr[strs.Length];
            int num_byte = 0;

            //  Copy 
            for (int i = 0; i != strs.Length; ++i)
            {
                str_array[i] = get_intptr_from_str(strs[i]);
                num_byte += System.Text.Encoding.Unicode.GetByteCount(strs[i]);
            }

            IntPtr str_ptr = Marshal.AllocHGlobal(num_byte);
            Marshal.Copy(str_array, 0, str_ptr, str_array.Length);
            //  Release the string pointer memory
            for (int i = 0; i != strs.Length; ++i)
            {
                free_intptr_memory(str_array[i]);
            }

            return str_ptr;
        }

        public static void free_global_intptr(IntPtr int_ptr)
        {
            Marshal.FreeHGlobal(int_ptr);
        }
    }
}
