﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestI2K.WSFundus
{
    public enum i2kRetinaErrorCode
    {
        /* --- success --- */
        success = 0,

        /* ----                          Major error code                                --- */
        /* Note: Most of the codes in this section were copied from da_plugin_error_code.h and maintained for backward compatibility.  */
        not_all_images_aligned = 1,    /* Partial success when not all images aligned */
        no_images_aligned = 5,    /* This is also the failure code */

        image_not_found = 2,
        image_read_error = 3,
        image_write_error = 4,
        argument_error = 7,
        bad_transformation = 9,
        out_of_memory = 10,
        invalid_license = 11,   /* fatal error in licensing, commonly caused by incorrect path */

        // User request to cancel
        request_cancel = 8,

        // Internal error. Keep for backward compatibility
        internal_error = 6,

        // High level API error
        non_existent_registration_id = 12,
        registration_has_not_been_run = 13,
        non_existent_component_index = 14,
        target_not_in_component = 15,
        target_not_selected = 16,
        subset_not_in_component = 17,
        target_not_in_align_subset = 18,
        synchronized_not_ready = 19,
        repeated_input_image_names = 20,

        too_many_images_for_memory_size = 21,
        wrong_number_of_images_for_band = 22,

        capture_group_id_does_not_exist = 23,
        capture_group_or_band_does_not_exist_or_no_intersection = 24,

        control_points_outside_image = 25,           /* mostly used in i2k PinPoint */

        operation_not_allowed = 26,         /* Operation is not allowed by the library */
        operation_failed = 27,         /* Operation was carried out, but failed */

        // General failure of library
        //main_auth_fail                 = 50,
        lib_not_initialized = 51,   /* Library initialization function was not called or resulted in error */
        lib_function_not_ready = 52,   /* Function is not ready.  It usually means some operations must be carried out before hand */
        lib_queue_full = 53,   /* Queue is full, must wait/process until it becomes available again */

        /* ---- file error ---- */
        file_generic = 100,
        file_create_temp = 101,  /* Cannot create a temporary file */
        file_create_new = 102,  /* Cannot create a non-temp and non-image file */
        file_create_folder = 103,  /* Cannot create a folder */
        file_write = 104,  /* Cannot write data */
        file_read = 105,  /* Cannot read data  */
        file_change_path = 106,  /* Cannot change path */
        file_delete_error = 107,  /* Cannot delete a file */

        file_path_error = 121,  /* Path error, e.g., path does not exist */

        /* ---- Common Algorithmic Exception ---- */
        alg_generic = 200,
        alg_non_finite_camera_residual = 201,   /* non finite residual during camera estimation */
        alg_invalid_H_matrix = 202,   /* invalid 3x3 Homography matrix */
        alg_unhandled_xform_distortion = 203,   /* Unhandled transformation distortion */

        alg_invalid_specification_of_pairs_to_try = 211,
        alg_invalid_specification_of_fixation_grid = 212,

        /* ---- Network Error ---- */
        net_generic = 300,
        net_init_interface = 301,  /* Cannot init (Winsock2) interface */
        net_create_socket = 302,  /* Fail to create socket */
        net_lookup_host = 303,  /* Fail to lookup host */
        net_connect = 304,  /* Fail to connect */
        net_send_data = 305,  /* Fail to send data */
        net_receive_data = 306,  /* Fail to receive data */
        net_shutdown_comm = 307,  /* Fail to carry out the shutdown() command */
        net_system_date_off = 308,  /* System's date is far off compared to network date */
        net_bad_response = 309,  /* Receive bad/invalid response from server*/

        net_http_invalid_header = 320,  /* Invalid header of HTTP request */


        /* ---- License and Activation ---- */
        lic_generic = 400,
        lic_combo_not_allowed = 401,  /* Wrong combination of the image type and function type */
        lic_activation_code = 402,  /* Invalid activation code */
        lic_xml_content = 403,  /* Invalid XML file content */
        lic_server_status = 404,  /* Bad/unsuccessful status code */
        lic_string_large = 405,  /* The string containing license content is too large to consume */
        lic_file_content = 406,  /* Invalid content in license file */
        lic_file_version = 407,  /* Invalid version for license file */
        lic_no_signature = 408,  /* No digital signature present */
        lic_invalid_signature = 409,  /* Invalid digital signature */
        lic_not_this_machine = 410,  /* Not allowed on this machine */
        lic_expired = 411,  /* License has already expired */
        lic_wrong_version = 412,  /* Applying license to a wrong version of software */
        lic_subscription_not_yet_renewed = 413,  /* The license is not yet renewed */
        lic_no_license = 414,  /* No license file (to deactivate) */
        lic_product_mismatch = 415,  /* Product Titile mismatch */
        lic_session_manager_failed = 416,  /* Fail to create internal session manager */
        lic_reached_max_num_sessions = 417,  /* The program reaches maximum number of simultaenous sessions.  Try again after some sessions are quited */
        lic_image_type_not_allowed = 418,  /* This image type is not allowed */
        lic_operation_not_allowed = 419,  /* This operation is not allowed */
        lic_too_many_images = 420,  /* Too many images used than allowed */
        lic_code_has_been_activated = 421,   /* The activation code has been activated already */
        lic_no_matching_token = 440,  /* Cannot find a matching token for the operation */


        /* ---- Trial/State File ---- */
        stt_generic = 500,
        stt_clock_before_release = 501,  /* Current system clock is set prior to the release date */
        stt_clock_after_expir = 502,  /* Current system clock is beyond internal expiration date */
        stt_date_backwards = 503,  /* During trial, the date goes backwards  */
        stt_over_trial_days = 504,  /* Exceeds max number of trial days */
        stt_over_trial_runs = 505,  /* Exceeds max number of trial runs */
        stt_file_tag = 506,  /* Bad state file tag */
        stt_file_content = 507,  /* Bad state file content */
        stt_invalid_status = 508,  /* Invalid status (or the state file is corrupted.) */
        stt_file_not_found = 509,  /* State file is not found */
        stt_file_not_operable = 510,  /* State file is not readable or writable */
        stt_locked_status = 511,  /* The state file is locked */


        /* ---- Machine Information ---- */
        mac_generic = 600,
        mac_gather_info = 601,  /* Cannot gather information on this computer */
        mac_id_damaged = 602,  /* Machine id string cannot be parsed */

        /* ---- Error from C++ STL library  ---- */
        stl_exception = 700,  /* Exception raised by STL library */
        crypt_exception = 701,  /* Exception raised by Crypto++ library */
        unknown_exception = 702,   /* Unknown exception */

        /* --- Error from save/load ---- */
        load_failure_generic = 800,  /* Cannot load registration */
        save_failure_generic = 801,  /* Cannot save registration */

        load_failure_bad_file_tag = 820,  /* Bad file tag in the ".ali" file.  It is likely the file was not saved by i2k software */
        load_failure_bad_transforms = 821,  /* Bad transforms during loading */

        save_failure_bad_image = 840,  /* Bad image when saving */


        /* --- Unknow Error --- */
        unknown_error = 999,  /* Unknown and unclassified error */


    };
}
