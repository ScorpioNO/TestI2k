﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestI2K.WSFundus;

namespace TestI2K
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            bool re = EditImage.init(textBox1.Text);
            if (!re)
            {
                button1.Enabled = false;
                button2.Enabled = false;
            }
        }

        /// <summary>
        /// 拼接
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            string path = "";
            var msg = GetImage(ref path);
            if (!string.IsNullOrEmpty(msg)) {
                pictureBox1.Image = null;
                MessageBox.Show(msg);
                return;
            }
            MessageBox.Show(path);
            if (!string.IsNullOrWhiteSpace(path)) {
                pictureBox1.Load(path);
            }
        }

        public string GetImage(ref string path)
        {
            try
            {
                string montage_file_name = EditImage.MontageMethod(textBox1.Text);
                //string montage_file_name = EditImage.Montage(textBox1.Text);
                string filename = string.Empty;
                if (!string.IsNullOrEmpty(montage_file_name))
                {
                    string[] patharray = montage_file_name.Split('\\');
                    filename = patharray[patharray.Length - 1];
                }
                if (!string.IsNullOrWhiteSpace(filename)) {
                    path = textBox1.Text + "\\" + filename;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private int ImageIndex = 0;
        private List<string> Align_url_Array = new List<string>();

        /// <summary>
        /// 校准
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            Align_url_Array.Clear();
            var msg = GetImageAlign(ref Align_url_Array);
            if (!string.IsNullOrEmpty(msg))
            {
                pictureBox2.Image = null;
                MessageBox.Show(msg);
                return;
            }

            ImageIndex = 0;
            pictureBox2.Load(Align_url_Array[ImageIndex]);

            button3.Visible = true;
            button4.Visible = true;
        }

        /// <summary>
        /// 同步对齐图像接口
        /// </summary>
        /// <param name="urls">url地址数组 (后 加入文件base64编码也可以直接上传)</param>
        /// <param name="username">用户名</param>
        /// <param name="password">密码</param>
        /// <param name="userId">用户id</param>
        /// <returns>FundusResult序列号对象，生成完成的对齐的图像url List </returns>
        public string GetImageAlign(ref List<string> Align_url_Array)
        {
            try
            {
                string[] Align_file_Array = EditImage.TestAlignMethods(textBox2.Text);
                string filename = string.Empty;
                if (Align_file_Array != null && Align_file_Array.Count() > 0)
                {
                    foreach (var Align_file_name in Align_file_Array)
                    {
                        string[] patharray = Align_file_name.Split('\\');
                        filename = patharray[patharray.Length - 1];
                        Align_url_Array.Add(textBox2.Text + "\\aligned-images\\" + filename);
                    }
                    return "";
                }
                else
                {
                    return "Align_file_Array is null or it's count is lower than 1";
                }
            }
            catch (Exception ex)
            {
                LogHelper.LogException.WriteError(ex);
                return "error";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (ImageIndex == 0) {
                MessageBox.Show("没有上一张");
                return;
            }
            ImageIndex--;
            pictureBox2.Load(Align_url_Array[ImageIndex]);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (ImageIndex == (Align_url_Array.Count-1))
            {
                MessageBox.Show("没有下一张");
                return;
            }
            ImageIndex++;
            pictureBox2.Load(Align_url_Array[ImageIndex]);
        }
    }
}
